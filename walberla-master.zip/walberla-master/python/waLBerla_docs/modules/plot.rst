***********
plot module
***********

.. automodule:: waLBerla.plot
   :members: