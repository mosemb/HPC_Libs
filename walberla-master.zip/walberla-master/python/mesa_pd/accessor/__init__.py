# -*- coding: utf-8 -*-

from .Accessor import create_access

__all__ = ['create_access']
